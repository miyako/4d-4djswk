/*
 * Javascript/HTML5 Particle Generator v0.1
 * http://scurker.com/projects/particles
 * 
 * Copyright (c) 2010 Jason Wilson, http://scurker.com
 * 
 * Licensed under the MIT license: http://www.opensource.org/licenses/mit-license.php
 */

/**
 * Extend an object and its properties
 * Idea mainly from jQuery's extend method
 */
var newFeatures = ["新しいタグ - 4DTEXT",
	"新しいタグ - 4DHTML",
	"外部プラグインになった4D Chart",
	"プロキシとして利用しやすくなったWebサーバー",
	"新しいタグ - 4DELSEIF",
	"新しいタグ - 4DBASE",
	"相対パスが使用できるようになった4DINCLUDE",
	"Content-Typeのリストを外部ファイルで定義",
	"keep-alive対応のHTTPクライアントコマンド群",
	"HTTPクライアント（取得） - HTTP GET",
	"HTTPクライアント（汎用） - HTTP REQUEST",
	"HTTPクライアント（設定） - HTTP SET OPTION",
	"HTTPクライアント（設定） - HTTP Get option",
	"HTTPクライアント（認証） - HTTP AUTHENTICATE",
	"BLOB/ピクチャ/テキストを外部ファイルで管理（自動）",
	"BLOB/ピクチャ/テキストを外部ファイルで管理（デベロッパー制御）",
	"外部レコードファイルパス設定",
	"外部レコードファイルパス取得",
	"外部レコードファイル再読み込み",
	"ピクチャフィールドをキーワードインデックス検索",
	"階層リストボックスの展開/収縮イベント",
	"デバッガ - 80文字以上の文字列ウォッチ",
	"デバッガ - エスケープ文字のサポート",
	"デバッガ - SQLコードを記述どおりに表示",
	"デバッガ - 行番号の表示",
	"デバッガ - コマンドシンタックスの表示",
	"デバッガ - 複数行の選択",
	"デバッガ - 実行中の行を矢印で指定",
	"デバッガ - インテリジェントな縦スクロール",
	"リストボックスヘッダー/行の高さを行数で設定",
	"リストボックスセルの垂直揃え",
	"リストボックスヘッダーの高さ設定",
	"リストボックスフッターの管理",
	"リストボックスフッターの関数を設定",
	"リストボックスフッターの関数を取得",
	"リストボックスフッターの高さ設定",
	"リストボックスフッターの高さ取得",
	"リストボックスロック列の設定",
	"リストボックスロック列の取得",
	"リストボックス固定列の設定",
	"リストボックス固定列の取得",
	"リストボックスのフッターを取得",
	"リストボックスのフッターを設定",
	"リストボックス列のフォーミュラを設定",
	"リストボックスのヘッダー/フッター情報を取得",
	"リストボックス行の高さを行数で設定",
	"リストボックス行の高さを行数で取得",
	"リストボックスのハイライトセット（取得） - LISTBOX GET TABLE SOURCE",
	"リストボックスのハイライトセット（設定） - LISTBOX SET TABLE SOURCE",
	"フッタークリックイベント",
	"階層リスト/リストボックスのアイテム削除フォームイベント",
	"リストボックスに複数行を一度に挿入",
	"リストボックスに複数行を一度に削除",
	"ウィンドウを最前面に移動しないでリサイズ",
	"リストアイテムのパラメーター名の配列を取得",
	"クエリデスティネーションの取得",
	"クエリリミットの取得",
	"ローカル変数に対するポインタでクエリデスティネーション設定",
	"ハッシュの生成 - Get digest",
	"新しいWebサーバー",
	"Webサーバーのセッション管理",
	"gzip圧縮",
	"スタティックページをプリエムティブスレッドで配信",
	"gzip圧縮 - WEB SEND FILE",
	"gzip圧縮 - WEB SEND TEXT",
	"gzip圧縮 - WEB SEND BLOB",
	"Webサーバーのオプション設定",
	"Webサーバーのオプション取得",
	"複数ファイルの同時アップロードを自動制御",
	"サブフォームウィジェット名の設定",
	"サブフォームウィジェット名の取得",
	"サブフォームコンテナのサイズ取得",
	"ピクチャの比較",
	"ピクチャからキーワードを取得",
	"ピクチャのファイル名を抽出",
	"新しいデータベースパラメーター",
	"gzip圧縮サポート - COMPRESS BLOB",
	"gzip圧縮サポート - EXPAND BLOB",
	"gzip圧縮サポート - BLOB PROPERTIES",
	"複数行に分けて記述できるSELECTION TO ARRAY",
	"複数行に分けて記述できるARRAY TO SELECTION",
	"システムイベントデータベースメソッド",
	"Webセッション管理",
	"ページ切り替えフォームイベント",
	"ストレクチャ検査でオブジェクトの重複を検出",
	"レコードの再保存",
	"アドレステーブルの圧縮",
	"メソッドの依存関係を検索",
	"フォームの依存関係を検索",
	"数値配列の平均値",
	"数値配列の最大値",
	"数値配列の最小値",
	"ウィンドウ最小化でデータベースイベント",
	"数値配列の標準偏差",
	"数値配列の合計",
	"数値配列の平方和",
	"重複フォームオブジェクト名の検出",
	"データファイルの圧縮",
	"QuickDraw塗りパターンを新しい描画体系に変換",
	"リストボックスセルの入力制御",
	"メニューアイテムショートカットキーの設定",
	"メニューアイテムショートカットキーの取得",
	"メニューアイテムモディファイアーの取得",
	"スクロールエリアをリストボックスに自動変換",
	"アプリケーションビルドのログ出力",
	"コード内省コマンド群",
	"メソッドコメントの取得",
	"メソッドコメントの設定",
	"メソッドコードの設定",
	"メソッドコードの取得",
	"メソッドプロパティの設定",
	"メソッドプロパティの取得",
	"メソッド変更日付の取得",
	"フォーム名のリスト取得",
	"メソッド名のリスト取得",
	"プリントプレビューにXPSビューアを使用",
	"プリントプレビュー設定の取得",
	"テキストを固定長文字列に分解",
	"テキストをキーワードの配列に分解",
	"オブジェクトプロパティ - 自動スペルチェックの取得",
	"オブジェクトプロパティ - 自動スペルチェックの設定",
	"オブジェクトプロパティ - ドラッグ＆ドロップの取得",
	"オブジェクトプロパティ - ドラッグ＆ドロップの設定",
	"オブジェクトプロパティ - フォーカス表示の取得",
	"オブジェクトプロパティ - フォーカス表示ティの設定",
	"オブジェクトプロパティ - ヘルプTipsの取得",
	"オブジェクトプロパティ - ヘルプTipsの設定",
	"オブジェクトプロパティ - キーボードレイアウトの取得",
	"オブジェクトプロパティ - キーボードレイアウトの設定",
	"オブジェクトプロパティ - リサイズの取得",
	"オブジェクトプロパティ - リサイズの設定",
	"オブジェクトプロパティ - ショートカットの取得",
	"オブジェクトプロパティ - ショートカットの設定",
	"オブジェクトプロパティ - 垂直揃えの取得",
	"オブジェクトプロパティ - 垂直揃えの設定",
	"統合されたWebKit",
	"新しいインストーラー",
	"中身を含めたフォルダのコピー",
	"再帰的なドキュメントリスト",
	"中間パスを含めたフォルダの作成",
	"ドキュメント選択でファイルを指定",
	"Hunspellスペルチェック辞書",
	"スペルチェック辞書のリストを取得",
	"スペルチェック辞書を設定",
	"テーブル断片化具合を取得",
	"SVG属性のオンメモリ設定",
	"64ビット版ODBCドライバー",
	"内部コードの整理",
	"Direct2Dサポート",
	"アンチエイリアス",
	"ハードウェアアクセラレーターの利用",
	"フォームオブジェクトのレンダリング改良",
	"Cocoa化計画スタート",
	"新しいグローバルプロセス管理",
	"カスタム定数をXLIFFファイルで定義",
	"IPV6サポート",
	"プログラスバーコンポーネント" ];

var newFeaturesLength = newFeatures.length;

function extend() {
  var target = arguments[0], length = arguments.length, i = 1, options;
  
  if(typeof target !== 'object' && toString.call(target) == "[object Function]")
    target = {};
  
  for(; i < length; i++) {
    if((options = arguments[i]) != null) {
      for(var name in options) {
        var src = target[name], copy = options[name];            
        if(copy !== undefined) 
          target[name] = copy;
      }
    }
  }
  
  return target;
}

/**
 * Basic Math Vector 
 * Used for vector calculations
 */    
var Vector = function(p) {
  p = extend({x: 0, y: 0}, p);
  this.x = p.x;
  this.y = p.y;
  return this;
};

Vector.prototype = {
  
  add: function(v) {
    this.x += v.x;
    this.y += v.y;
    return this;
  },
  
  clone: function() {
    return new Vector({x: this.x, y: this.y});
  },
  
  distance: function(v) {
    var x = this.x - v.x,
        y = this.y - v.y;
    return Math.sqrt(x * x + y * y);
  },
  
  length: function() {
    return Math.sqrt(this.x * this.x + this.y * this.y);
  },
  
  points: function(p) {
    if(p === undefined) return {x: this.x, y: this.y};
    p = extend(this.p, p);
    this.x = p.x;
    this.y = p.y;
    return this;    
  },
  
  rotate: function(rad) {
    var cos = Math.cos(rad), sin = Math.sin(rad), x = this.x, y = this.y;
    this.x = x * cos - y * sin;
    this.y = x * sin + y * cos;
    return this;
  },
  
  subtract: function(v) {
    this.x -= v.x;
    this.y -= v.y;
    return this;
  }        
  
};

var ParticleGenerator = function(options) {
  
  var options = extend({
  /*
    shape: 'circle',
    velocity: new Vector({x: 0, y: -5}),
    xVariance: 0,
    yVariance: 0,
    spawnSpeed: 5,
    generations: 100000,
    maxParticles: 25,
    size: 8,
    sizeVariance: 6,
    life: 100,
    lifeVariance: 50,    
    direction: 0,
    directionVariance: 35,
    color: '#cef',
    opacity: 1,
    onDraw: function(p) {
      var y = -this.age * 3;
      p.size *= 0.98;
      p.color = 'rgb(255, ' + (y + 255) + ', 68)';
      p.opacity = 0.5 - (p.age / p.life * 0.4);
    }
    */
    shape: 'circle',
	velocity: new Vector({x: 0, y: -6.5}),
	xVariance: 0,
	yVariance: 0,
	spawnSpeed: 5,
	generations: 100000,
	maxParticles: 12,
	size: 8,
	sizeVariance: 6,
	life: 180,
	lifeVariance: 50,    
	direction: 0,
	directionVariance: 35,
	color: 'white', // '#cef'
	opacity: 0,
	onDraw: function(p) {
	  p.v.add(new Vector({y: 0.1}));
	  p.opacity = /*1 - */ (p.age / p.life * 0.9);
	  if(this.isJoke) {
	  	p.opacity *= 2;
	  	if(p.opacity > 0.9)
	  		p.opacity = 0.9;
	  }
   }
  }, options);
  
  this.p = options.position;
  this.v = options.velocity;
  this.options = options;
  this.active = true;
  this.age = 0;
  
  return this;  
};

ParticleGenerator.prototype = {
    
  particles: [],
    
  update: function() {
  
    // Check to see if we've reached the max # of generation cycles
    if(this.options.generations != -1 && this.age <= this.options.generations) {
      if(this.particles.length == 0 && this.options.generations <= this.age)
      	this.active = false;
      this.age++;
    }
  
    // Update any existing particles; check for dead particles
    for(var i in this.particles) {
      var particle = this.particles[i];
      if(particle.active === false) {
        this.particles.splice(i, 1); 
      } else {
        particle.update(); 
      }
    }
  
    // Generate # (spawnSpeed) of particles for this update iteration
    // as long as we haven't reached the max # of particles
    for(var spawned = 0; spawned < this.options.spawnSpeed; spawned++) {
      if(this.particles.length >= this.options.maxParticles || this.options.generations <= this.age) {
        return; 
      }
      this.particles.push(new Particle(this.options));
    }
  },
  
  draw: function(ctx) {
    for(var i in this.particles) {
      this.particles[i].draw(ctx);
    }
  },
    
};

var jokeDone = false;
var totalParticles = 0;
var countToIgnore = -1;
var jokeCountDown = -1;

var Particle = function(options) {
  
  // output a random variance number
  var rand = function(num) { return (Math.random() * num << 1) - num; };
  
  // Set the initial position variance
  var position = new Vector({x: rand(options.xVariance), y: rand(options.yVariance)});
  
  // Set the initial particle directional heading
  var direction = options.direction + rand(options.directionVariance);
  
  var theLabel = '';
  var isTheJoke = false;
  if(!jokeDone) {
		totalParticles++;
		if(totalParticles > 50) {
			if(jokeCountDown < 0) {
				jokeCountDown = 4;
			} else {
				theLabel = "For sale: MacBook Pro - contact Thibaud";
				isTheJoke = true;
				jokeDone = true;
				countToIgnore = 4;
			}
		}
 	}
 	if(--jokeCountDown < 0 && --countToIgnore < 0) {
		if(theLabel ===  '') {
			theLabel = newFeatures[ Math.round( 1 + (Math.random() * (newFeaturesLength - 1))) ];
		}
	}
  
  extend(this, options, {
    p: options.position.clone().add(position),
    v: options.velocity.clone().rotate(direction * Math.PI/180),
    age: 0,
    life: options.life + rand(options.lifeVariance),
    size: options.size + rand(options.sizeVariance),
    active: true,
    isJoke : isTheJoke,
    text: theLabel
  });
  
  return this;  
};

Particle.prototype = {
  
  update: function() {
    if(this.age >= this.life)
    	this.active = false;
    this.p.add(this.v);
    this.age++;
    
    if(this.isJoke && this.age >= (this.life/4))
    	this.color = 'yellow';
    
  },
  
  draw: function(ctx) {
    if(typeof this.onDraw === 'function')
    	this.onDraw(this);
    ctx.save();
    ctx.fillStyle = this.color;
    try {
      ctx.globalAlpha = this.opacity;
    } catch(ex) {
      console.debug(ex); 
    }
    ctx.translate(this.p.x, this.p.y);
	ctx.fillText(this.text, 0, 0);
    ctx.restore();
  }
  
};

function ParticleCanvas(canvas, pos) {
  if(!canvas)
  	return;
  
  this.ctx = canvas.getContext('2d');
  this.height = canvas.height;
  this.width = canvas.width;
  
  this.intervalID = null;
  
  // Set default position (center) if one doesn't exist
  pos = extend({x: this.width/2, y: this.height/2}, pos);
  
  this.particleGenerator = new ParticleGenerator({position: new Vector(pos)});
  
  return this;
};


ParticleCanvas.prototype = {
	
  // Set the frame rate
  start: function() {
    var self = this;
    
    self.intervalID = setInterval(function() { self.tick(); }, (1000/60)*2);
    return self.intervalID;
    //return setInterval(function() { self.tick(); }, (1000/60)*2);
  },
  
  stop: function() {
  	clearInterval(this.intervalID);
  	this.intervalID = null;
  },
  
  // Initialize the canvas per frame
  init: function() {
    var ctx = this.ctx;
    ctx.clearRect(0, 0, this.width, this.height);
    ctx.fillStyle = '#000';
    ctx.beginPath();
    ctx.fillRect(0, 0, this.width, this.height);
    ctx.stroke();
    ctx.font = "48px sans-serif";
    ctx.drawImage(document.getElementById("zeBG"), 0, 0, 1000, 800);
    ctx.save();
    
  },
  
  update: function(options) {    
    
    // Convert any numerics to numbers
    for(var i in options) {
      options[i] = isNaN(parseFloat(options[i])) ? options[i] : parseFloat(options[i]);
    }
    
    if(!(options.velocity instanceof Vector))
      options.velocity = new Vector({y: -options.velocity});
    
    options.directionVariance = parseInt(options.directionVariance);
    
    extend(this.particleGenerator.options, options);
  },

  tick: function() {
    this.init();
    
    this.particleGenerator.update(this.ctx);
    this.particleGenerator.draw(this.ctx);
  }
    
};