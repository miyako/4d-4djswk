Introduction to Build Automation - Example 04/06/2011 

Requirements:
============ 

4D v12 is required in order to use the provided sample database. If you 
wish to use 4D v11 SQL, create "MyCoolDatabase" in 4D v11 SQL and copy 
all methods from the v12 database (don't forget "On Startup"). Then 
place the 4D v11 SQL database in the "source" folder (replacing the 4D 
v12 version). 

Installation:
============ 

-Launch MyCoolDatabase.4dbase in 4D v12. This will automatically 
configure the 4DLINK file for building. The Designer password is "d". 
-Quit 4D.
-Place a copy of 4D in the "4d_for_build" folder. Note: on 
Windows it should be "\4d_for_build\4D" and on Mac it should be 
"/4d_for_build/4D.app".  I other words copy the entire folder/package.

Build:
===== 

Windows:

-Double-click "bin\01_Build.bat" to build. 

Mac OS X:

-Open a Terminal window and navigate to the "bin" folder using 
"cd".
-Type "./01_Build.bat" and press return. 

The final releases will be in the "release" folder. Interpreted 
structures are included in the "debug" folder inside the release. 
